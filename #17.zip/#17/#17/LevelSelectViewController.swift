//
//  LevelSelect.swift
//  #17
//
//  Created by Yoshi on 6/17/16.
//  Copyright © 2016 litech. All rights reserved.
//

import UIKit

class LevelSelectViewController: UIViewController {
    
    var stageNumber: Int = 0
    
    let defaults = NSUserDefaults.standardUserDefaults()
    
    @IBOutlet weak var textField: UITextField!
    
    @IBOutlet var scrollView: UIScrollView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        scrollView.pagingEnabled = true
        scrollView.showsHorizontalScrollIndicator = false
        scrollView.showsVerticalScrollIndicator = false
        scrollView.decelerationRate = UIScrollViewDecelerationRateFast
        let contentView = UIView(frame: CGRectMake(0,0,self.scrollView.frame.width*2,self.scrollView.frame.height))
        scrollView.contentSize = contentView.frame.size
        
        for i in 0..<2
        {
            let view = UIView(frame: CGRectMake(scrollView.frame.width*CGFloat(i), 0, self.scrollView.frame.width,self.scrollView.frame.height))
            
            for m in 0...2{
                for n in 0...2{
                    let button = UIButton(frame: CGRectMake(CGFloat(m) * scrollView.frame.width/3, CGFloat(n) * scrollView.frame.height/3, scrollView.frame.width/3, scrollView.frame.height/3))
                    button.addTarget(self, action: #selector(LevelSelectViewController.selectLevel(_:)), forControlEvents: .TouchUpInside)
                    button.setTitle(String(n*3+m+i*9+1), forState: .Normal)
                    button.backgroundColor = UIColor(red: 187/255, green: 189/255, blue: 192/255, alpha: 1)
                    button.setTitleColor(UIColor.whiteColor(), forState: .Normal)
                    button.titleLabel!.font = UIFont(name: "Thonburi",size: CGFloat(25))
                    
                    button.tag = (n*3+m+i*9)+1
                    print(button.tag)
                    view.addSubview(button)
                }
            }
            contentView.addSubview(view)
        }
        scrollView.addSubview(contentView)
    }
    
    
    func selectLevel (button:UIButton){
        stageNumber = button.tag
        defaults.setValue(String(stageNumber), forKey: "currentNumber")
        performSegueWithIdentifier("toViewController",sender: nil)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}
